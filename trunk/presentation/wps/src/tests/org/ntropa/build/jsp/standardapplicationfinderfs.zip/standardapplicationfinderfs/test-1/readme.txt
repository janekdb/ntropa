This directory should be empty aprt from this file
